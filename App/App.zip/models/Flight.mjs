class Flight {

    constructor(flight_id, plan_id, airline, flight_number, departure_date, departure_time, arrival_date, arrival_time, departure_airport, arrival_airport) {
        this.flight_id = flight_id;
        this.plan_id = plan_id;
        this.airline = airline;
        this.flight_number = flight_number;
        this.departure_date = departure_date;
        this.departure_time = departure_time;
        this.arrival_date = arrival_date;
        this.arrival_time = arrival_time;
        this.departure_airport = departure_airport;
        this.arrival_airport = arrival_airport;
    }
    
    manageReservations() {

    }

    checkForUpcomingReservations() {

    }

    validateReservationData() {

    }
    
    calculateDataChanges() {

    } 

    calculateNewDataSum() {

    }

    updateDatabase() {
        
    }
}
