class User {
    
    constructor(username, user_id, email, password, created_at) {
        this.username = username;
        this.user_id = user_id;
        this.email = email;
        this.password = password;
        this.created_at = created_at;
    }

    hasUserAccount() {

    }

    
    balanceNotification() { //if budget balance low

    }
    
    saveReport() {

    }
    
    requestBudgetDestribution() {

    }
    
    requestExpenses() {

    }
    
    buildPlan() {

    }
    
    requestPlanData() {

    }
    
    requestFromSuggestions() {

    }       
    
    setPlanVisibility() {

    }

    requestVisibility() {

    }
    
    requestReservationChanges() {

    }

    search() {
        
    }
    updateDatabase() {
        
    }
}
