class Feedback {

    constructor(username, user_id, plan_name, plan_id) {
        this.username = username;
        this.user_id = user_id;
        this.plan_name = plan_name;
        this.plan_id = plan_id;
    }

    updateDatabase() {
        
    }
}
