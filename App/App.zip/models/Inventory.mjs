class Inventory {
    
    updateDatabase() {
        
    }
}
