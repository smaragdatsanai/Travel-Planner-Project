class Destination {
    
    constructor(plan_id, location) {
        this.plan_id = plan_id;
        this.location = location;
        }

    checkForUpcomingReservations() {

    }

    
    manageReservations() {

    }
    
    validateReservationData() {

    }
    
    calculateDataChanges() {

    } 

    calculateNewDataSum() {

    }

    updateDatabase() {

    }
}
