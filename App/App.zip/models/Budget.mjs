class Budget {
    
    constructor(expense, state) {
        this.expense = expense;
        this.state = state;
    }

    budgetManagement() {

    }
    
    budgetAnalysis() {

    }
    
    analyzeExpenses() { //if budget sufficient

    }
    
    budgetManagement() {

    }
    
    budgetLow() {   //save request

    }
    
    budgetDestribution() {

    }
    
    addExpenses() {

    }
    
    analyzeBudgetState() {

    }
    
    
    provideSavingOptions() {

    }
    
    updateDatabase() {
        
    }
}
