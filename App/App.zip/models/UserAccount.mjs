class UserAccount {

    constructor(username, user_id, email, password, created_at) {
        this.username = username;
        this.user_id = user_id;
        this.email = email;
        this.password = password;
        this.created_at = created_at;
    }

    createUserAccount() {

    }
    
    loginAsGuest() {
        
    }
    
    userLoginAuthentication() {

    }
    
    updateDatabase() {
        
    }
}
