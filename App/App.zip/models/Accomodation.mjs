class Accomodation {

    constructor(accomodation_id, plan_id, name, check_in_date, check_in_time, check_out_date, check_out_time, location) {
        this.accomodation_id = accomodation_id;
        this.plan_id = plan_id;
        this.name = name;
        this.check_in_date = check_in_date;
        this.check_in_time = check_in_time;
        this.check_out_date = check_out_date;
        this.check_out_time = check_out_time;
        this.location = location;
    }

    
    
    checkForUpcomingReservations() {

    }
    
    manageReservations() {

    }
    
    validateReservationData() {

    }
    
    calculateDataChanges() {

    } 

    calculateNewDataSum() {

    }

    updateDatabase() {
        
    }
}
