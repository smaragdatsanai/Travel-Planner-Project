class Activities {

    constructor(activity_id, plan_id, name, date, start_time, end_time, location) {
        this.activity_id = activity_id;
        this.plan_id = plan_id;
        this.name = name;
        this.date = date;
        this.start_time = start_time;
        this.end_time = end_time;
        this.location = location;
    }
    
    checkForUpcomingReservations() {

    }
    
    manageReservations() {

    }
    
    validateReservationData() {

    }
    
    calculateDataChanges() {

    } 

    calculateNewDataSum() {

    }

    updateDatabase() {
        
    }
}
