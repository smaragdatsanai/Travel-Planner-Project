class TravelPlan {

    constructor(plan_id, user_id, plan_name, destination, start_date, end_date) {
        this.plan_id = plan_id;
        this.user_id = user_id;
        this.plan_name = plan_name;
        this.destination = destination;
        this.start_date = start_date;
        this.end_date = end_date;
    }
    
    fillForm() {

    }

    submitEmptyForm() {

    }

    createPlan() {

    }

    choosePlan() {

    }

    viewPlan() {
        
    }

    enrichPlan() {

    }

    chooseTopDestination() {

    }

    configureDetails() {

    }

    cantCreatePlan() {

    }
    
    planNotFound() {

    }
    
    dataAuthentication() {

    }
    
    provideSuggestions() {

    }
    
    getPlanVisibility() {

    }
    
    updateDatabase() {
        
    }
}
