import * as accomodation from '../models/Accomodation.mjs'

class AccommodationController {

    static async findAccommodation(req, res) {
        try {

        }catch(error){
            next(error)
        }
    }

    static async checkAccommodationAvailability(req, res) {
        try {

        }catch(error){
            next(error)
        }
    }

    
}

export {AccomodationController}